<?php
/**
 * Email Footer
 *
 * @package 	Give/Templates/Emails
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

// This is the footer used if no others are available

?>
    </body>
</html>